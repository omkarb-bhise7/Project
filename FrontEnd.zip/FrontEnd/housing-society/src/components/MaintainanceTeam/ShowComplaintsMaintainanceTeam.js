import axios from "axios";
import { useEffect, useState } from "react";
import { Button } from "react-bootstrap";
import { useParams } from "react-router-dom";

const ShowComplaintsMaintainanceTeam = () => {
  let id = useParams();
  let numberid = parseInt(id.id);
  console.log(numberid);

  const [notice, setNotice] = useState([]);
  useEffect(() => {
    axios
      .get(`http://localhost:8080/maintainanceteam/complaint/show/${numberid}`)
      .then((res) => {
        console.log(res);
        setNotice(res.data);
      });
  }, []);

  function handleclick(ccid) {
    axios
      .get(
        
    `http://localhost:8080/maintainanceteam/complaint/resolve/${ccid}`
      )
      .then((res) => console.log("success"))
      .catch(() => console.log("Error"));
      window.location.reload(false);
  }
  return (
    <div>
      <table className="table table-striped" style={{border:"solid"}}>
        <thead class="thead-dark" style={{border:"solid"}}>
          <tr>
            <th scope="col" style={{border:"solid"}}>ID</th>
            <th scope="col" style={{border:"solid"}}>Complaint Date</th>
            <th scope="col" style={{border:"solid"}}> Description</th>
            <th scope="col" style={{border:"solid"}}>status</th>
            <th scope="col" style={{border:"solid"}}>Resolve Date</th>
          </tr>
        </thead>
        {notice.map((current) => {
          return (
            <>
              <tr scope="row">
                <td style={{border:"solid"}}> {current.cid}</td>
                <td style={{border:"solid"}}> {current.complaintDate}</td>
                <td style={{border:"solid"}}> {current.descriptions}</td>
                <td style={{border:"solid"}}> {current.status}</td>
                <td style={{border:"solid"}}> {current.resolveDate}</td>
                <td style={{border:"solid"}}>
                  {" "}
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => handleclick(current.cid)}
                  >
                    Resolve
                  </button>{" "}
                </td>
              </tr>
            </>
          );
        })}
      </table>
    </div>
  );
};
export default ShowComplaintsMaintainanceTeam;
