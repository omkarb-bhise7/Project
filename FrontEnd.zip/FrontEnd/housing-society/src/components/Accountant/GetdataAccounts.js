import axios from "axios";
import { useEffect, useState  } from "react";
import { useParams } from "react-router-dom"; 
import { Link } from "react-router-dom";


const GetdataAccounts=()=>{
  let id =useParams();
  let numberid= parseInt(id.id);
  console.log(numberid);
  let user;

const [user7, setUser7] = useState([])



  useEffect(() => {
    user = axios.get(`http://localhost:8080/accountant/getdata/${numberid}`).then((res)=>{
    console.log(res)
      setUser7(res.data)
      console.log(user7)
      
  })
  }, [])
    
  return(
<div>
  <table className="table" style={{border:"solid"}}>
  <tr>
        <th scope="col" style={{border:"solid"}}>Id</th>
        <th scope="col" style={{border:"solid"}}>Paid</th>
        <th scope="col" style={{border:"solid"}}>Total Maintainance</th>
        <th scope="col" style={{border:"solid"}}>Due Date</th>
        <th scope="col" style={{border:"solid"}}>Assign Date</th>
        <th scope="col" style={{border:"solid"}}>Description</th>
    </tr>
{
  user7.map((current)=>{
    return(
      <>
      <tr>
      <td style={{border:"solid"}}> {current.id}</td>
      <td style={{border:"solid"}}> {current.paid}</td>
      <td style={{border:"solid"}}> {current.totalMaintainance}</td>
      <td style={{border:"solid"}}> {current.dueDate}</td>
      <td style={{border:"solid"}}> {current.assignDate}</td>
      <td style={{border:"solid"}}>{current.description}</td>
      </tr> 
      </>
    )
  })
}
     
</table>
</div>
  )
}
export default GetdataAccounts;