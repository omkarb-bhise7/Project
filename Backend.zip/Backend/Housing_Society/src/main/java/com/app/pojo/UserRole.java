package com.app.pojo;

public enum UserRole {
	SECRETARY , ACCOUNTANT , OWNER ,TENANT ,MAINTAINANCE_TEAM

}
