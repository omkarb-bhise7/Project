package com.app.repositoryTemp;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.app.pojo.OwnerTemp;
import com.app.pojo.User;

public interface OwnerRepositoryTemp extends JpaRepository<OwnerTemp, Long> {

	

}
