package com.app.repositoryTemp;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojo.TenantTemp;
import com.app.pojo.User;

public interface TenantRepositoryTemp extends JpaRepository<TenantTemp, Long> {

	
	
	
}
