package com.app.pojo;

public enum ComplaintStatus {
	
	RESOLVED , PENDING ,IN_PROGRESS
	

}
